import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import bodyParser from 'body-parser';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(bodyParser.json());

// In-memory data stores (replace with a real DB for production)
const users: Record<string, { id: string, username: string }> = {};
const trades: Record<string, { id: string, ownerId: string, title: string, description: string, items: string[], status: 'open' | 'traded' }> = {};
const tradeRequests: Record<string, { id: string, tradeId: string, requesterId: string, message: string, status: 'pending' | 'accepted' | 'declined' }> = {};
const chats: Record<string, { id: string, user1: string, user2: string, messages: { sender: string, content: string, time: number }[] }> = {};

// User registration (simple)
app.post('/api/register', (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'Username required' });
  const id = uuidv4();
  users[id] = { id, username };
  res.json({ id, username });
});

// List a trade
app.post('/api/trades', (req, res) => {
  const { ownerId, title, description, items } = req.body;
  if (!users[ownerId]) return res.status(400).json({ error: 'Invalid owner' });
  const id = uuidv4();
  trades[id] = { id, ownerId, title, description, items, status: 'open' };
  res.json(trades[id]);
});

// View all trades
app.get('/api/trades', (req, res) => {
  res.json(Object.values(trades).filter(t => t.status === 'open'));
});

// Send trade request
app.post('/api/trade-requests', (req, res) => {
  const { tradeId, requesterId, message } = req.body;
  if (!trades[tradeId] || trades[tradeId].status !== 'open') return res.status(400).json({ error: 'Invalid trade' });
  if (!users[requesterId]) return res.status(400).json({ error: 'Invalid user' });
  const id = uuidv4();
  tradeRequests[id] = { id, tradeId, requesterId, message, status: 'pending' };
  res.json(tradeRequests[id]);
});

// Accept or decline trade request
app.post('/api/trade-requests/:id/respond', (req, res) => {
  const { id } = req.params;
  const { status } = req.body; // 'accepted' or 'declined'
  const request = tradeRequests[id];
  if (!request || !['accepted', 'declined'].includes(status)) return res.status(400).json({ error: 'Invalid' });
  request.status = status;
  if (status === 'accepted') {
    trades[request.tradeId].status = 'traded';
    // Create chat between users
    const ownerId = trades[request.tradeId].ownerId;
    const requesterId = request.requesterId;
    const chatId = uuidv4();
    chats[chatId] = { id: chatId, user1: ownerId, user2: requesterId, messages: [] };
    res.json({ success: true, chatId });
  } else {
    res.json({ success: true });
  }
});

// Get user's chats
app.get('/api/chats/:userId', (req, res) => {
  const { userId } = req.params;
  if (!users[userId]) return res.status(400).json({ error: 'Invalid user' });
  const userChats = Object.values(chats).filter(chat => chat.user1 === userId || chat.user2 === userId);
  res.json(userChats);
});

// Get chat messages
app.get('/api/chat/:chatId', (req, res) => {
  const { chatId } = req.params;
  if (!chats[chatId]) return res.status(404).json({ error: 'Chat not found' });
  res.json(chats[chatId].messages);
});

// Real-time chat via Socket.io
io.on('connection', (socket) => {
  socket.on('joinChat', ({ chatId, userId }) => {
    if (chats[chatId] && (chats[chatId].user1 === userId || chats[chatId].user2 === userId)) {
      socket.join(chatId);
    }
  });

  socket.on('sendMessage', ({ chatId, sender, content }) => {
    if (!chats[chatId] || !users[sender]) return;
    const message = { sender, content, time: Date.now() };
    chats[chatId].messages.push(message);
    io.to(chatId).emit('newMessage', message);
  });
});

server.listen(3000, () => {
  console.log('Garden trading site backend running on port 3000');
});