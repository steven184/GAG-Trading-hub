import mongoose from 'mongoose';

export const User = mongoose.model('User', new mongoose.Schema({
  username: String,
  password: String,
}));

export const Trade = mongoose.model('Trade', new mongoose.Schema({
  userId: mongoose.Types.ObjectId,
  title: String,
  description: String,
  items: [String],
  status: String, // open, traded
}));

export const TradeRequest = mongoose.model('TradeRequest', new mongoose.Schema({
  tradeId: mongoose.Types.ObjectId,
  requesterId: mongoose.Types.ObjectId,
  message: String,
  status: String, // pending, accepted, declined
}));

export const Message = mongoose.model('Message', new mongoose.Schema({
  room: String,
  senderId: mongoose.Types.ObjectId,
  content: String,
  timestamp: Number,
}));