import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

const socket = io('http://localhost:3001');

function App() {
  const [user, setUser] = useState(null);
  const [trades, setTrades] = useState([]);
  const [messages, setMessages] = useState([]);
  const [chatRoom, setChatRoom] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    axios.get('http://localhost:3001/api/trades').then(res => setTrades(res.data));
  }, []);

  function sendMessage() {
    socket.emit('message', { room: chatRoom, senderId: user.userId, content: message });
    setMessage('');
  }

  useEffect(() => {
    socket.on('message', msg => setMessages(msgs => [...msgs, msg]));
    return () => socket.off('message');
  }, []);

  function joinRoom(room) {
    setChatRoom(room);
    socket.emit('joinRoom', room);
    setMessages([]);
  }

  // ...render sign up, list trades, send trade requests, join chat, chat UI, etc.
  // This is a minimal skeleton. You can expand with forms and routing as needed.

  return (
    <div>
      <h1>Garden Trading Site</h1>
      {/* Registration/Login UI */}
      {/* Trade listing UI */}
      {/* Trade request UI */}
      {/* Chat UI */}
      <div>
        <input value={message} onChange={e => setMessage(e.target.value)} />
        <button onClick={sendMessage}>Send</button>
        <div>
          {messages.map((msg, i) => (
            <div key={i}>{msg.content}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;