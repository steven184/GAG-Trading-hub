import express from 'express';
import http from 'http';
import mongoose from 'mongoose';
import cors from 'cors';
import { Server } from 'socket.io';

// Models
import { User, Trade, TradeRequest, Message } from './models';

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/garden_trading');

// REST API

// Sign up
app.post('/api/signup', async (req, res) => {
  const { username, password } = req.body;
  const user = new User({ username, password });
  await user.save();
  res.json({ userId: user._id, username });
});

// List trade item
app.post('/api/trades', async (req, res) => {
  const { userId, title, description, items } = req.body;
  const trade = new Trade({ userId, title, description, items, status: 'open' });
  await trade.save();
  res.json(trade);
});

// Get all trades
app.get('/api/trades', async (req, res) => {
  const trades = await Trade.find({ status: 'open' });
  res.json(trades);
});

// Send trade request
app.post('/api/trade-requests', async (req, res) => {
  const { tradeId, requesterId, message } = req.body;
  const tradeRequest = new TradeRequest({ tradeId, requesterId, message, status: 'pending' });
  await tradeRequest.save();
  res.json(tradeRequest);
});

// Accept/decline trade request
app.post('/api/trade-requests/:id/respond', async (req, res) => {
  const { status } = req.body;
  const request = await TradeRequest.findById(req.params.id);
  request.status = status;
  await request.save();
  if (status === 'accepted') {
    const trade = await Trade.findById(request.tradeId);
    trade.status = 'traded';
    await trade.save();
  }
  res.json(request);
});

// Chat system
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
io.on('connection', (socket) => {
  socket.on('joinRoom', (room) => socket.join(room));
  socket.on('message', async (data) => {
    const { room, senderId, content } = data;
    const msg = new Message({ room, senderId, content, timestamp: Date.now() });
    await msg.save();
    io.to(room).emit('message', msg);
  });
});

server.listen(3001, () => {
  console.log('Server running on port 3001');
});