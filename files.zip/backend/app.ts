import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';
import User from './models/User';
import Trade from './models/Trade';
import TradeRequest from './models/TradeRequest';
import Message from './models/Message';

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/garden_trading');

// User registration/login endpoints (add JWT for production)
app.post('/api/register', async (req, res) => {
  // ...register user
});
app.post('/api/login', async (req, res) => {
  // ...login user
});

// Trade endpoints
app.post('/api/trades', async (req, res) => {
  // ...create trade
});
app.get('/api/trades', async (req, res) => {
  // ...list/search trades
});

// Trade request endpoints
app.post('/api/trade-requests', async (req, res) => {
  // ...send request
});
app.post('/api/trade-requests/:id/respond', async (req, res) => {
  // ...accept/decline request
});

// Real-time chat with Socket.io
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

io.on('connection', (socket) => {
  socket.on('joinRoom', (roomId) => socket.join(roomId));
  socket.on('message', async (msg) => {
    const message = await Message.create(msg);
    io.to(msg.chatRoom).emit('message', message);
  });
});

server.listen(3001, () => console.log('Server running on 3001'));