import mongoose from 'mongoose';

const TradeSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  title: String,
  description: String,
  tags: [String],
  photos: [String],
  status: { type: String, enum: ['open', 'traded'], default: 'open' },
  requests: [{ type: mongoose.Schema.Types.ObjectId, ref: 'TradeRequest' }]
});

export default mongoose.model('Trade', TradeSchema);