import mongoose from 'mongoose';

const TradeRequestSchema = new mongoose.Schema({
  trade: { type: mongoose.Schema.Types.ObjectId, ref: 'Trade' },
  requester: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  message: String,
  status: { type: String, enum: ['pending', 'accepted', 'declined'], default: 'pending' },
  chatRoom: String // Unique room ID for chat
});

export default mongoose.model('TradeRequest', TradeRequestSchema);