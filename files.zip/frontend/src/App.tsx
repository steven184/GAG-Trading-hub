import React, { useEffect, useState } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

const socket = io('http://localhost:3001');

function App() {
  // States for user, trades, requests, chat, etc.
  // Fetch trades, send requests, join chat room, send messages

  return (
    <div>
      <h1>Garden Trading Community</h1>
      {/* Registration/Login */}
      {/* List trades, search trades */}
      {/* List trade requests */}
      {/* Chat (per trade/request) */}
      {/* Notifications */}
      {/* ...expand as needed */}
    </div>
  );
}

export default App;